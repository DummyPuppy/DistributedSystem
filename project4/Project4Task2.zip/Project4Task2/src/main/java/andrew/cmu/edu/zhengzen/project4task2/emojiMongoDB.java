package andrew.cmu.edu.zhengzen.project4task2;
/**
 * Email: zhengzen@andrew.cmu.edu Author: Zheng Zeng This is the mongoDB model that can save a
 * document object onto mongoDB and extract all documents in a collection
 */
import com.google.gson.Gson;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.codecs.configuration.CodecProvider;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.codecs.pojo.PojoCodecProvider;

import java.util.*;

import static com.mongodb.MongoClientSettings.getDefaultCodecRegistry;
import static org.bson.codecs.configuration.CodecRegistries.fromProviders;
import static org.bson.codecs.configuration.CodecRegistries.fromRegistries;

// ...

public class emojiMongoDB {
  /**
   * save method: to save an emojiInfo object to mongoDB
   *
   * @param info
   */
  public void save(emojiInfo info) {
    // initiate provider
    CodecProvider pojoCodecProvider = PojoCodecProvider.builder().automatic(true).build();

    // new url:
    // mongodb://chloezeng:P74pGuHwmkuT0zR4@clusterchloe-shard-00-00.vphsd.mongodb.net:27017,clusterchloe-shard-00-01.vphsd.mongodb.net:27017,clusterchloe-shard-00-02.vphsd.mongodb.net:27017/emoji_pool?w=majority&retryWrites=true&tls=true&authMechanism=SCRAM-SHA-1
    // build a registry
    CodecRegistry pojoCodecRegistry =
        fromRegistries(getDefaultCodecRegistry(), fromProviders(pojoCodecProvider));
    // start the connection
    String uri =
        "mongodb://chloezeng:P74pGuHwmkuT0zR4@clusterchloe-shard-00-00.vphsd.mongodb.net:27017,clusterchloe-shard-00-01.vphsd.mongodb.net:27017,clusterchloe-shard-00-02.vphsd.mongodb.net:27017/emoji_pool?w=majority&retryWrites=true&tls=true&authMechanism=SCRAM-SHA-1";
    MongoClient mongoClient = MongoClients.create(uri);
    // Replace the uri string with your MongoDB deployment's connection string
    try {

      // find the database
      MongoDatabase database =
          mongoClient.getDatabase("emoji_pool").withCodecRegistry(pojoCodecRegistry);
      // find the collection
      MongoCollection<emojiInfo> collection = database.getCollection("emoji_data", emojiInfo.class);
      collection.insertOne(info); // insert the data
      System.out.println("successfully insert one data of content");
    } catch (Exception e) {
      e.getMessage();
      e.printStackTrace();
    } finally {
      // close the connection
      mongoClient.close();
    }
  }

  /**
   * this method extract all documents in one collection
   *
   * @return
   */
  public List<emojiInfo> extractAll() {
    // initiate provider
    CodecProvider pojoCodecProvider = PojoCodecProvider.builder().automatic(true).build();
    // new url:
    // mongodb://chloezeng:P74pGuHwmkuT0zR4@clusterchloe-shard-00-00.vphsd.mongodb.net:27017,clusterchloe-shard-00-01.vphsd.mongodb.net:27017,clusterchloe-shard-00-02.vphsd.mongodb.net:27017/emoji_pool?w=majority&retryWrites=true&tls=true&authMechanism=SCRAM-SHA-1
    // build a registry
    CodecRegistry pojoCodecRegistry =
        fromRegistries(getDefaultCodecRegistry(), fromProviders(pojoCodecProvider));
    // Replace the uri string with your MongoDB deployment's connection string
    String uri =
        "mongodb://chloezeng:P74pGuHwmkuT0zR4@clusterchloe-shard-00-00.vphsd.mongodb.net:27017,clusterchloe-shard-00-01.vphsd.mongodb.net:27017,clusterchloe-shard-00-02.vphsd.mongodb.net:27017/emoji_pool?w=majority&retryWrites=true&tls=true&authMechanism=SCRAM-SHA-1";
    // start the connection
    MongoClient mongoClient = MongoClients.create(uri);
    try {
      // connect to the database and collection
      MongoDatabase database =
          mongoClient.getDatabase("emoji_pool").withCodecRegistry(pojoCodecRegistry);
      MongoCollection<emojiInfo> collection = database.getCollection("emoji_data", emojiInfo.class);
      // create a list to store all documents
      List<emojiInfo> data = new ArrayList<>();
      // store all documents into the list data
      collection.find().into(data);
      System.out.println("print all the entries");
      //            System.out.println(data);
      return data;
    } catch (Exception e) {
      // dealing with exception
      e.getMessage();
      e.printStackTrace();
      return null;
    } finally {
      // close the connection
      mongoClient.close();
    }
  }
}
