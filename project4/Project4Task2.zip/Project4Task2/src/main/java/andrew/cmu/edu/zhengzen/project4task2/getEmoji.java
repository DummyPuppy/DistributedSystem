/**
 * Email: zhengzen@andrew.cmu.edu Author: Zheng Zeng This class is the model for the web service
 * this class would retrieve a list of emojis from Github Emojis and find the one that fits the
 * user's need.
 */
package andrew.cmu.edu.zhengzen.project4task2;

import com.google.gson.Gson;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.HashMap;
import java.util.Set;

public class getEmoji {
  // the url to get the dictionary of the emojis
  String url = "https://api.github.com/emojis?accept=application/vnd.github.v3+json";
  // a HashMap object to store all the emoji
  HashMap emoji_map;
  // gson is used to parse JSON file
  Gson gson = new Gson();
  // a HashMap object to store the selected emoji and later turned into a JSON file to send to the
  // client.
  Emoji emoji;
  long response_time; // the time for github emoji to return the list of all emojis
  long fetch_time;
  // constructor
  public getEmoji() throws IOException, InterruptedException {
    retrieveEmojiMap();
  }
  // retrieve the list of emojis
  private void retrieveEmojiMap() throws IOException, InterruptedException {
    long start = System.currentTimeMillis();
    HttpClient client = HttpClient.newHttpClient();
    HttpRequest request =
        (HttpRequest)
            HttpRequest.newBuilder(URI.create(url))
                .header("Content-Type", "application/json")
                .build();
    HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

    emoji_map = gson.fromJson(response.body(), HashMap.class);
    long end = System.currentTimeMillis();
    setResponse_time(end - start);
    System.out.println("Having retrieve all emojis!");
  }

  // get the emoji image url according to the keyword given
  // there are error-handling codes here to deal with server-side problem
  public String getEmojiIcon(String key_word) {
    long start = System.currentTimeMillis();
    if (key_word == null) {
      return "nothing is given";
    } else {
      String image = (String) emoji_map.get(key_word.toLowerCase());
      // error handling: if the user enters a word that is not in the map
      // find its closest meaning of emoji
      if (image == null) {
        // loop over the map to find the first key that contains such a word
        for (String key : (Set<String>) emoji_map.keySet()) {
          if (key.contains(key_word)) {
            image = (String) emoji_map.get(key);
            break;
          }
        }
        // if still cannot find the emoji
        if (image == null) {
          // set it to default image url
          image = "andrew/cmu/edu/zhengzen/emoji/emojiservlet/404notfound.png";
          System.out.println("cannot find the image");
        } else {
          System.out.println("the most similar image url is " + image);
        }
      } else {
        System.out.println("the image url is " + image);
      }
      // set the map of the information of the key-value pair
      emoji = new Emoji(key_word, image);
      // transform it into json file and return it
      long end = System.currentTimeMillis();
      setFetch_time(end - start);
      return gson.toJson(emoji, Emoji.class);
    }
  }

  public void setResponse_time(long response_time) {
    this.response_time = response_time;
  }

  public void setFetch_time(long fetch_time) {
    this.fetch_time = fetch_time;
  }

  public long getResponse_time() {
    return response_time;
  }

  public long getFetch_time() {
    return fetch_time;
  }

  public Emoji getEmoji() {
    return emoji;
  }
}
