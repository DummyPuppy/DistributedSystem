/**
 * author: zhengzen email: zhengzen@andrew.cmu.edu This is the main web service that get a string
 * from the user and return a json file containing the emoji image url
 */
package andrew.cmu.edu.zhengzen.project4task2;

import com.google.gson.Gson;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
// set the path name to be getemoji
@WebServlet(
    name = "getEmojiServlet",
    urlPatterns = {"/getAnEmoji"})
public class getEmojiServlet extends HttpServlet {
  private getEmoji emoji; // the model to get the emoji
  private emojiInfo info; // the object to be stored in mongoDB
  private emojiMongoDB
      saveToMongoDB; // the mongoDB object to execute save and extract data from the cloud
  private int sequence; // to record the number of sending requests

  public void init() {
    // initiate all objects
    try {
      emoji = new getEmoji();
      info = new emojiInfo();
      saveToMongoDB = new emojiMongoDB();
      sequence = 0;
    } catch (IOException e) {
      // catch any exception
      // handling any java side problem
      e.printStackTrace();
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  /**
   * the doGet method to deal with request and send a json file string to the writer
   *
   * @param request
   * @param response
   * @throws IOException
   */
  public void doGet(HttpServletRequest request, HttpServletResponse response)
      throws IOException, ServletException {
    sequence += 1; // everything a get request comes, add up on the sequence
    response.setContentType("text/html");
    String keyword = request.getParameter("keyword");
    // check if the key word is correct
    // acquire the json string from emoji object
    long get_req = System.currentTimeMillis();
    String emoji_image = emoji.getEmojiIcon(keyword);
    // set the emojiInfo object's instance variables
    info.setRequest_time(emoji.getResponse_time());
    info.setFetch_time(emoji.getFetch_time());
    info.setKeyword(keyword);
    info.setImg_url(emoji_image);
    info.setSequence(sequence);
    // set up the response
    response.setContentType("application/json");
    // write the answer to response
    response.getWriter().write(emoji_image);
    long send_res = System.currentTimeMillis();
    // till now can we set up the total response time to the Android application
    info.setReply_time(send_res - get_req);
    // save the data to mongoDB
    saveToMongoDB.save(info);
  }

  public void destroy() {}
}
