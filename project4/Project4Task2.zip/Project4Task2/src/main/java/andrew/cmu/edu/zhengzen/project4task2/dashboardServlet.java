/**
 * Email: zhengzen@andrew.cmu.edu Author: Zheng Zeng This is the servlet view to present the
 * dashboard
 */
package andrew.cmu.edu.zhengzen.project4task2;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

// set up the url pattern
@WebServlet(
    name = "dashboardServlet",
    urlPatterns = {"/emojiDashboard"})
public class dashboardServlet extends HttpServlet {
  emojiMongoDB mongoDB; // the mongoDB driver to extract data

  public void init() throws ServletException {
    mongoDB = new emojiMongoDB(); // initiate the mongoDB driver object
  }

  @Override
  protected void doGet(HttpServletRequest req, HttpServletResponse resp)
      throws ServletException, IOException {
    // extract the list of documents from the collection
    List<emojiInfo> data_list = mongoDB.extractAll();
    // compute the average values for the three response time variables
    double request_time =
        (double) data_list.stream().collect(Collectors.averagingLong(emojiInfo::getRequest_time));
    req.setAttribute(
        "average_request_time",
        request_time); // set an attribute in the request as the average value
    double fetch_time =
        (double) data_list.stream().collect(Collectors.averagingLong(emojiInfo::getFetch_time));
    req.setAttribute("avg_fetch_time", fetch_time); // same step as before
    double response_time =
        (double) data_list.stream().collect(Collectors.averagingLong(emojiInfo::getReply_time));
    req.setAttribute("avg_resp_time", response_time);
    // set the list to be one of the attribute for further data manipulation
    req.setAttribute("list_of_emoji_use", data_list);
    // dispatch the request to the view
    RequestDispatcher view = req.getRequestDispatcher("index.jsp");
    view.forward(req, resp);
  }
}
