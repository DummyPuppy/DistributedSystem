package andrew.cmu.edu.zhengzen.project4task2;

import java.sql.Timestamp;

/**
 * Email: zhengzen@andrew.cmu.edu
 * Author: Zheng Zeng
 * this is the class that mongoDB stored all information about a request/reply
 **/
public class emojiInfo {
    String keyword;//keyword for the request/response
    int sequence; //the sequence of this request
    String img_url;
    long request_time;//the time when the user prompts for an emoji
    long fetch_time; //the time when the 3-rd party API responses with the result
    long reply_time; // the time when the web service reply the emoji required

    /**
     * setters and getters
     *
     */
    public  emojiInfo(){

    }

    public long getReply_time() {
        return reply_time;
    }

    public long getRequest_time() {
        return request_time;
    }

    public long getFetch_time() {
        return fetch_time;
    }

    public String getKeyword() {
        return keyword;
    }

    public String getImg_url() {
        return img_url;
    }

    public void setReply_time(long reply_time) {
        this.reply_time = reply_time;
    }

    public void setRequest_time(long request_time) {
        this.request_time = request_time;
    }

    public void setFetch_time(long response_time) {
        this.fetch_time = response_time;
    }

    public void setImg_url(String img_url) {
        this.img_url = img_url;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public void setSequence(int sequence) {
        this.sequence = sequence;
    }

    public int getSequence() {
        return sequence;
    }

    @Override
    public String toString() {
        return "emojiInfo{" +
                "keyword='" + keyword + '\'' +
                ", img_url='" + img_url + '\'' +
                ", request_time=" + request_time +
                ", fetch_time=" + fetch_time +
                ", reply_time=" + reply_time +
                '}';
    }
}
