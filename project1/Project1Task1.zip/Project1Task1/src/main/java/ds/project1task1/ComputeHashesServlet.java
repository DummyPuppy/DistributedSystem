/**
 * author: zhengzen
 * class: ComputeHashesServlet
 * usage: communicate with the browser and get the request and response value to compute hashes.
 */
package ds.project1task1;

import java.io.*;
import java.security.NoSuchAlgorithmException;

import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet(name = "ComputeHashesServlet", value = "/ComputeHash")
public class ComputeHashesServlet extends HttpServlet {
    private String message;
    private ComputeHashes ch;
    String computeType = "MD5";
    String hex = "";
    String base64 = "";
    @Override
    public void init() {
        ch = new ComputeHashes();
    }

    //acquire the compute data type and the input string
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html;charset=UTF-8");
        try {
            message = request.getParameter("inputString");
            System.out.println(message);
            computeType = request.getParameter("method");
            System.out.println(computeType);
            if (computeType =="MD5"){
                ch.computeMD5(message);
            }else {
                ch.computeSHA(message);
            }
            hex = ch.showHex();
            base64 = ch.showBase64();
            response.setContentType("text/html");
            // Print out result
            PrintWriter out = response.getWriter();
            out.println("<html><body>");
            out.println("<h1>" + "Original text:" + message+ "</h1>");
            out.println("<h1>" + computeType +" Hex value: "+hex + "</h1>");
            out.println("<h1>" + computeType +" Base64 value: "+base64+"</h1>");
            out.println("</body></html>");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
    }

    public void destroy() {
    }
}