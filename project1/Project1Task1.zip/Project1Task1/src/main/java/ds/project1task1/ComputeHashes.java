/**
 * author: zhengzen
 * class: ComputeHashes
 * usage: to compute the hash values of the designated string
 */
package ds.project1task1;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class ComputeHashes {
    MessageDigest md;
//constructor
    public ComputeHashes()  {
    }
//to compute SHA hash
    public void computeSHA(String s) throws NoSuchAlgorithmException {

        try{
            md = MessageDigest.getInstance("SHA-256");
            md.update(s.getBytes());
            //get SHA-256 hexstring

        }catch (Exception e){
            e.getStackTrace();
        }
//        System.out.println(md.digest());
//        System.out.println(message);
    }
    //to compute MD5 hash
    public void computeMD5(String s) throws NoSuchAlgorithmException {

        try{
            md = MessageDigest.getInstance("MD5");
            md.update(s.getBytes());
            //get SHA-256 hexstring

        }catch (Exception e){
            e.getStackTrace();
        }
//        System.out.println(md.digest());
//        System.out.println(message);
    }
    //to demonstrate the hash in Hex
    public String showHex(){
//        System.out.println(jakarta.xml.bind.DatatypeConverter.printHexBinary(md.digest()));
        if (md != null){
            return  jakarta.xml.bind.DatatypeConverter.printHexBinary(md.digest());
        }else {
            return null;
        }

    }
    //to demonstratre the hash in Base 64
    public String showBase64(){
//        System.out.println(jakarta.xml.bind.DatatypeConverter.printBase64Binary(md.digest()));
        return jakarta.xml.bind.DatatypeConverter.printBase64Binary(md.digest());
    }
//    public static void main(String[] args) {
//        ComputeHashes ch = new ComputeHashes();
//        ch.computeSHA("Hello World");
//        ch.showHex();
//        ch.showBase64();
//    }

}
