package ds.project1task3;

import java.io.*;
import java.util.Map;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet(name = "clicker", urlPatterns = {"/get-clicker","/getResults"})
public class ClickerServlet extends HttpServlet {
    public ClickerModel cm ;
    private int resultcount =0 ;
    public void init() {

        cm = new ClickerModel();
    }
    //the  doPost method will deal with
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        getDevice(request);//check the device' mode: desktop or mobile?

        String message = request.getParameter("choice");
//        if (message !=null){ //check if the message is null
//            System.out.println("message received "+ message);
//        }
        //add the answer to the class
        cm.addCount(message);
        request.setAttribute("last_choice", message); //save the answer to be displayed on the next page
//test if it reaches the threshold
        if (resultcount >10){
            request.setAttribute("answers", cm.getAns());
            //direct to the getResults page
            String redirect = "/Project1Task3-1.0-SNAPSHOT/getResults";
            response.sendRedirect(redirect);
        }else {
            //keep asking for answers
            resultcount++; //count the number of answers input. If it reached threshold, stop.
            RequestDispatcher view = request.getRequestDispatcher("index.jsp");
            view.forward(request, response);
        }

        }
        //this is the get method that the getResult page uses to get the answer counts.
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        //check the mobile/desktop type
        getDevice(request);
        //get the answers dictionary
        Map<String,Integer> ans = cm.getAns();
        //if the page has a url link of getResults
        if (request.getServletPath().contains("/getResults")) {
            //set the attribute of the answer count
            request.setAttribute("a-value", ans.get("A"));
            request.setAttribute("b-value", ans.get("B"));
            request.setAttribute("c-value", ans.get("C"));
            request.setAttribute("d-value", ans.get("D"));
            // if the page is the get-clicker page, re-direct it to the getResult page
            if (request.getServletPath().contains("get-clicker")) {
            String redirect = "/Project1Task3-1.0-SNAPSHOT/getResults";
            response.sendRedirect(redirect);
        } else {
                //redirected to the getResult page
            RequestDispatcher view = request.getRequestDispatcher("getResult.jsp");
            view.forward(request, response);
        }
    }else {
            RequestDispatcher view = request.getRequestDispatcher("index.jsp");
            view.forward(request, response);
        }
            }
            //check if the device is a PC or mobile
    protected void getDevice(HttpServletRequest request){
        // determine what type of user's device
        String ua = request.getHeader("User-Agent");

        //prepare the appropriate DOCTYPE for the view pages
        if (ua != null && ((ua.indexOf("Android") != -1) || (ua.indexOf("iPhone") != -1))) {
            request.setAttribute("doctype", "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.2//EN\" \"http://www.openmobilealliance.org/tech/DTD/xhtml-mobile12.dtd\">");
        } else {
            request.setAttribute("doctype", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">");
        }
    }
    public void destroy() {
        cm.ans.clear();
    }
}