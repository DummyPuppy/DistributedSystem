package ds.project1task3;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * to deal with the input answer and counting
 */
public class ClickerModel {
    public Map<String,Integer> ans = new HashMap<>();
    //constructor
    //default 4 choices
    //automatically become a new array with no stored results
    public ClickerModel(){
    }
//A is the first one, B the second, C then, D  last.
    public void addCount(String choice) {
        if (ans.containsKey(choice)){
           ans.put(choice,ans.get(choice) +1);
        }else {
            ans.put(choice,1);
        }

    }
//get the answer array fast
    public Map<String, Integer> getAns() {
        return ans;
    }

    @Override
    public String toString() {
        return "ClickerModel{" +
                "ans=" + "\n A: "+ans.get("A")+ "\n B:"+ ans.get("B")+"\n C: "+ ans.get("C");
    }
//
//    public static void main(String[] args) {
//        ClickerModel cm = new ClickerModel();
//        cm.addCount("A");
//        cm.addCount("C");
//        cm.addCount("B");
//        cm.addCount("A");
//        cm.addCount("D");
//        cm.addCount("A");
//        Map m = cm.getAns();
//        if (m!=null){
//            System.out.println("m is not null");
//        }
//        System.out.println(cm);
//    }
}
