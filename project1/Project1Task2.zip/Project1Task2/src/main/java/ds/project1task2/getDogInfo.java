/**
Author: Zheng Zeng
Instruction: This is the main java file to scrap data from websites and API
 Class include: dogInfo, a class to store dog's profile information
 Methods include: dogInfo.getProfile(), get Image()
 */
package ds.project1task2;

import com.google.gson.Gson;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Map;

public class getDogInfo {
    //initiate some base variables
    //the image link
    String image;
    //the website or API link
    public String credit = "https://dog.ceo/api/";
    public String profile = "https://dogtime.com/dog-breeds/profile";
    String api ;
    //the replied json file
    String response ="";
    //a dog's profile list
    dogInfo info;

    //constructor
    public getDogInfo(){
        //initiate a dog profile object
        info = new dogInfo();

    }

    static class dogInfo{
        //all the profile information required
        String friendly;
        String intelligence;
        String height;
        String weight;
        String lifespan;
        //constructor of the inner class
        public dogInfo(){
        }
        //method to get the profile
        public void getProfile(String name){
            try {
                //scrap profile information from the website
                String profile = "https://dogtime.com/dog-breeds/" +name.toLowerCase(Locale.ROOT)+"#/slide/1";
                Document doc = Jsoup.connect(profile).get();
                Elements character = doc.getElementsByClass("breed-characteristics-ratings-wrapper paws");
                for (Element e : character){
                    if (e.getElementsByClass("characteristic-title").text().contains("Intelligence")){
                        intelligence = e.getElementsByClass("characteristic-star-block").get(1).text()+ "Star";
                    }
                    if (e.getElementsByTag("h3").get(0).text().trim().contains("Friendliness")){
                        friendly = e.getElementsByClass("characteristic-star-block").text().split(" ")[0]+ "Star";
                    }
                }
                Elements vital = doc.getElementsByClass("vital-stat-box");
                height= vital.get(1).text();
                weight =vital.get(2).text();
                lifespan = vital.get(3).text();
//                System.out.printf(friendly,intelligence,height,weight,lifespan);

            } catch (MalformedURLException e) {
                e.printStackTrace();
            }catch ( IOException e){
                e.printStackTrace();
            }
        }
    }


    public String getImage(String name) throws IOException {
        //https://dog.ceo/api/breed/hound/images
        this.api = "https://dog.ceo/api/breed/"+name+"/images";
        URL urlstring = new URL(api);
        HttpURLConnection connection = (HttpURLConnection) urlstring.openConnection();
        // Read all the text returned by the server
        BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
        Gson dogjson = new Gson();
        String s;
        while ((s= in.readLine()) != null){
            response+=s;
        }
        Map result = dogjson.fromJson(response, Map.class);
        ArrayList<String> images = (ArrayList<String>) result.get("message");
//        System.out.println(images);
        image = images.get(images.size()/2);
        return image;
    }

//    public static void main(String[] args) {
//        try {
//            String name= "Collie";
//            getDogInfo g = new getDogInfo();
//            String image = g.getImage("hound");
//            System.out.println(image);
//            g.info.getProfile(name);
//        }catch (Exception e){
//            e.getStackTrace();
//        }

//    }
}
