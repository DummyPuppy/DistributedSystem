/**
 * author: zhengzen
 * class:DogServlet
 * usage:to scrap web data about a specific dog breed
 */
package ds.project1task2;

import java.io.*;
import java.util.Locale;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet(name = "FindDogServlet", value = "/findDogBreed")
public class DogServlet extends HttpServlet {
    private String dog_type;
    getDogInfo getinfo;
    private String Image;
    public void init() {

        try {
            //a class to get the infomation required by the next page
            getinfo= new getDogInfo();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    //the doGet methods handle requests and send back required information.

    public void doGet(HttpServletRequest request, HttpServletResponse response){
        response.setContentType("text/html");
        String next = "result.jsp";
        dog_type = request.getParameter("dogbreed").toLowerCase(Locale.ROOT);
        try{
//when a dog type is selected
            if (dog_type !=null){
                System.out.println(dog_type);
                //acquire the dogInfo class's instance variable values.
                getinfo.info.getProfile(dog_type);
                //get the image link of a random dog breed photo
                Image = getinfo.getImage(dog_type);
                //set the attributes for the browser
                request.setAttribute("picture",Image);
                request.setAttribute("dog-breed",dog_type);
                request.setAttribute("ProfileCredit",getinfo.profile);
                request.setAttribute("Friendly",getinfo.info.friendly);
                request.setAttribute("Intelligence",getinfo.info.intelligence);
                request.setAttribute("Height", getinfo.info.height);
                request.setAttribute("Weight", getinfo.info.weight);
                request.setAttribute("Lifespan",getinfo.info.lifespan);
                request.setAttribute("PictureCredit",getinfo.credit);
                RequestDispatcher reqdis= request.getRequestDispatcher(next);
                reqdis.forward(request,response);
            }else {
                //if the dog breed is not selected, ask to input a dog breed.
                RequestDispatcher req = request.getRequestDispatcher("index.jsp");
                req.forward(request,response);
            }



        }catch (Exception e){

        }

    }

    public void destroy() {
    }
}